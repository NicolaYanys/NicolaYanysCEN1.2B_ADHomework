#ifndef BOOK_DIVISION_H
#define BOOK_DIVISION_H

#define MAX_BOOKS 1000

void divideBooksAmongEmployees(int books[], int num_books, int num_employees);

#endif // BOOK_DIVISION_H
